### ############################################################################################################
### ############################################################################################################
###	#	
### # Project: 			#		Robbie News Plugin
###	#	
### # Email @ spinal.11@gmail.com
### #
### # Dedicated to Robyn - you're the best!
### #
### ############################################################################################################
### ############################################################################################################

### ############################################################################################################
##### Imports #####
import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
### ############################################################################################################

addonID = 'plugin.video.robbie_news'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')
path = local.getAddonInfo('path').decode('utf-8')

def cFL( t,c="green"): return '[COLOR '+c+']'+t+'[/COLOR]' ### For Coloring Text ###

YOUTUBE_SEARCH_1 = "fox+news+live"
YOUTUBE_SEARCH_2 = "cnn+live"
YOUTUBE_SEARCH_3 = "MSNBC+live"
YOUTUBE_SEARCH_4 = "CBS+news+live"
YOUTUBE_SEARCH_5 = "BBC+news+live"
YOUTUBE_SEARCH_6 = "SKY+news+live"
YOUTUBE_SEARCH_7 = "RT+America+live"
YOUTUBE_SEARCH_8 = "AL+Jazeera+English+live"
YOUTUBE_SEARCH_9 = "Tucker Carlson"
YOUTUBE_SEARCH_10 = "Rachel Maddow"
YOUTUBE_SEARCH_11 = "The Young Turks"
YOUTUBE_SEARCH_12 = "Infowars"
YOUTUBE_SEARCH_13 = "Rebel Media Edge"
YOUTUBE_SEARCH_14 = "Louder with Crowder"
YOUTUBE_SEARCH_15 = "The Ben Shapiro Show"
YOUTUBE_SEARCH_16 = "Joe Rogan Podcast"

# Entry point
def run():
    plugintools.log("robbie_news.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("robbie_news.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title=cFL("Fox News",'red'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_1,
        thumbnail=path+"/resources/foxnews_logo.png",
        fanart=path+"/resources/foxnews_fanart.png",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title=cFL("CNN News",'blue'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_2,
        thumbnail=path+"/resources/cnn_logo.png",
        fanart=path+"/resources/cnn_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("MSNBC News",'blue'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_3,
        thumbnail=path+"/resources/msnbc_logo.png",
        fanart=path+"/resources/msnbc_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("CBS News",'blue'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_4,
        thumbnail=path+"/resources/cbs_logo.png",
        fanart=path+"/resources/cbs_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("BBC News",'blue'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_5,
        thumbnail=path+"/resources/bbc_logo.png",
        fanart=path+"/resources/bbc_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("SKY News",'blue'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_6,
        thumbnail=path+"/resources/skynews_logo.png",
        fanart=path+"/resources/skynews_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("RT America",'red'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_7,
        thumbnail=path+"/resources/RT_logo.png",
        fanart=path+"/resources/RT_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("AL Jazeera",'blue'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_8,
        thumbnail=path+"/resources/ALJazeera_logo.png",
        fanart=path+"/resources/ALJazeera_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("Tucker Carlson (Not Live)",'red'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_9,
        thumbnail=path+"/resources/TC_logo.png",
        fanart=path+"/resources/TC_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("Rachel Maddow (Not Live)",'blue'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_10,
        thumbnail=path+"/resources/RM_logo.png",
        fanart=path+"/resources/RM_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("The Young Turks",'blue'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_11,
        thumbnail=path+"/resources/TYT_logo.png",
        fanart=path+"/resources/TYT_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("InfoWars",'red'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_12,
        thumbnail=path+"/resources/InfoWars_logo.png",
        fanart=path+"/resources/InfoWars_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("Rebel Media",'red'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_13,
        thumbnail=path+"/resources/TRM_logo.png",
        fanart=path+"/resources/TRM_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("Louder with Crowder",'red'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_14,
        thumbnail=path+"/resources/LWC_logo.png",
        fanart=path+"/resources/LWC_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("The Ben Shapiro Show",'red'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_15,
        thumbnail=path+"/resources/TBS_logo.png",
        fanart=path+"/resources/TBS_fanart.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=cFL("Joe Rogan Podcast",'green'),
        url="plugin://plugin.video.youtube/kodion/search/query/?q="+YOUTUBE_SEARCH_16,
        thumbnail=path+"/resources/TJRE_logo.png",
        fanart=path+"/resources/TJRE_fanart.png",
        folder=True )

run()

################################################################################################################
